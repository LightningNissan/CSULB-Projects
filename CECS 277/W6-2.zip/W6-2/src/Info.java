public interface Info 
{
	/** 
	 * Displays the info of the Shape 
	 */
	public void info(); 
}

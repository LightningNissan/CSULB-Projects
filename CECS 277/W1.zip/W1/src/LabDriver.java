/** 
 * This code is demonstrating java docs 
 * @author Nishaan Amin  
 * version 0.1 
 */
public class LabDriver 
{
	/** 
	 * 
	 * @param args put a description 
	 */
	public static void main(String[] args) 
	{ /* 
		System.out.println("Hello World"); 
		System.out.println("Hello World"); 
		System.out.println("Hello World"); 
		System.out.println("Hello World"); */  
		System.out.println("Hello World");  
		/* 
		 * Multiple Lines Comment 
		 */
		/** java docs 
		 * 
		 */
	} //end main 
} //end class  

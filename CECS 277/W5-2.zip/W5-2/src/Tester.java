public class Tester 
{
	public static void main(String[] args) 
	{
		Student s1 = new Student("Bob", 21, 12345); 
		Student s2 = new Student("Michael", 25, 123); 
	}

}

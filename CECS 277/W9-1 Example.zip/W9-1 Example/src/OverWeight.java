public class OverWeight extends Exception 
{
	public OverWeight() 
	{ 
		super("Weight Tantrum"); 
		System.out.println("Go to the gym");
	}
}

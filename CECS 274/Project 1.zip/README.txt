I use the F4 and F5 key to compile and run my code, but I have no 
idea what IDE you are using. Can I use my grace period for 
my assignment? 

1_1_length 
 - Compile and run the 1_1_length file 

1_2_dynamic_array  
 - Compile and run the 1_2_dynamic_array file 

1_3_array_queue 
 - Compile and run the 1_3_array_queue file 

1_4_array_stack 
 - Compile and run the 1_4_array_stack file 

1_5_queue  
 - Compile and run the 1_5_queue file 
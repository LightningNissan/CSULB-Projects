import random

from nose.tools import *
# import the directory
from listtest import exercise_list

def test_as():
    exercise_list(ArrayStack())

    
    


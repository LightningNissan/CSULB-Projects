Just compile and run the the files 1_1, 1_2, and 1_3 





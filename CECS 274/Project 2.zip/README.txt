Just compile and run the the files 1_1 to 1_5  










